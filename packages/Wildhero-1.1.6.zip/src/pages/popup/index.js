import{e}from"../../../assets/js/extensionWrapper.1444ec87.js";import{p as o,j as r}from"../../../assets/js/clsx.fdea109b.js";import"../../../assets/js/index.cb9abe85.js";o.ready().then(()=>{e(r.jsx(r.Fragment,{}))});
//# sourceMappingURL=index.js.map
