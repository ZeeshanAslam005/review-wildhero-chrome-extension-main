import './assets/js/index.ts.a63c37d5.js';
